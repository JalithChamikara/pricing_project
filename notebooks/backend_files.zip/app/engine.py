"""Loads the trained model and the pricing engine, and builds a price recommendation for each day."""
import importlib.util
import json
from datetime import date, timedelta
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import shap

# The scraped market prices were collected for check-in dates in this month (October 2026).
SNAPSHOT_MONTH = 10
# The seasonal shape of competitor prices is limited to this range,
# so one unusual month cannot make prices jump too much.
SHAPE_MIN, SHAPE_MAX = 0.8, 1.4


class PricingService:
    def __init__(self, models_dir: str, data_dir: str):
        models_dir, data_dir = Path(models_dir), Path(data_dir)

        self.model = joblib.load(models_dir / "xgboost.pkl")
        self.features = joblib.load(models_dir / "features.pkl")
        with open(models_dir / "train_median.json") as f:
            self.train_median = json.load(f)

        spec = importlib.util.spec_from_file_location("pricing_engine", models_dir / "pricing_engine.py")
        self.pe = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.pe)

        self.explainer = shap.TreeExplainer(self.model)

        hist = pd.read_csv(data_dir / "main_clean.csv", parse_dates=["Date"])
        hist["Month"] = hist.Date.dt.month
        # Normal (average) values for each month. We use these for future days,
        # because real tourist arrivals for the future are not known yet.
        self.profile = hist.groupby("Month").agg(
            arrivals=("SLTDA_Tourist_Arrivals", "mean"),
            lead=("Booking_Lead_Time", "mean"),
            season_norm=("Seasonality_Index_Norm", "mean"),
            season_code=("Season_Code", "mean"),
            occupancy=("Historical_Occupancy_Rate", "mean"),
            comp=("Competitor_Avg_Price_LKR", "mean"),
        )
        self.market = pd.read_csv(data_dir / "market_summary.csv")

    # ---------- market reference ----------
    def districts(self):
        return sorted(self.market.district.unique().tolist())

    def property_types(self):
        return sorted(self.market.property_type.unique().tolist())

    def market_reference(self, district: str, property_type: str):
        """Median scraped price for this district and property type, with fallbacks."""
        m = self.market
        exact = m[(m.district == district) & (m.property_type == property_type)]
        if len(exact) and exact["count"].iloc[0] >= 3:
            r = exact.iloc[0]
            return float(r.median_lkr), "district + property type", int(r["count"])
        d = m[m.district == district]
        if len(d):
            return float(np.average(d.median_lkr, weights=d["count"])), "district only", int(d["count"].sum())
        t = m[m.property_type == property_type]
        if len(t):
            return float(np.average(t.median_lkr, weights=t["count"])), "property type only", int(t["count"].sum())
        return float(np.average(m.median_lkr, weights=m["count"])), "all scraped hotels", int(m["count"].sum())

    def competitor_price_for_month(self, market_level: float, month: int) -> float:
        """Market price level (from the scrape) x seasonal shape (from history)."""
        shape = self.profile.comp.loc[month] / self.profile.comp.loc[SNAPSHOT_MONTH]
        return float(market_level * np.clip(shape, SHAPE_MIN, SHAPE_MAX))

    # ---------- features for a future day ----------
    def build_features(self, d: date, arrivals_change_pct: float = 0.0, demand_surge: bool = False) -> dict:
        p = self.profile.loc[d.month]
        arrivals = p.arrivals * (1 + arrivals_change_pct / 100)
        return {
            "SLTDA_Tourist_Arrivals": arrivals,
            "Booking_Lead_Time": p.lead,
            "Seasonality_Index_Norm": p.season_norm,
            "Season_Code": float(round(p.season_code)),
            "Day_of_Week": d.weekday(),
            "Is_Weekend": int(d.weekday() >= 5),
            "Month": d.month,
            "Demand_Surge_Flag": int(demand_surge),
            "Arrivals_Lag7": arrivals,
            "Arrivals_Roll7": arrivals,
            "Occupancy_Lag7": p.occupancy,
        }

    # ---------- main functions ----------
    def forecast(self, start: date, end: date, arrivals_change_pct=0.0, demand_surge=False):
        days = [start + timedelta(days=i) for i in range((end - start).days + 1)]
        rows = pd.DataFrame([self.build_features(d, arrivals_change_pct, demand_surge) for d in days])[self.features]
        pred = np.clip(self.model.predict(rows), 0, 100)
        return days, rows, pred

    def recommend(self, district, property_type, base_rate, start, end,
                  arrivals_change_pct=0.0, demand_surge=False, competitor_price=None):
        days, rows, pred = self.forecast(start, end, arrivals_change_pct, demand_surge)
        shap_values = self.explainer.shap_values(rows)

        if competitor_price is not None:
            level, source, n = float(competitor_price), "entered by the owner", 0
        else:
            level, source, n = self.market_reference(district, property_type)

        out = []
        for i, d in enumerate(days):
            comp = float(competitor_price) if competitor_price is not None else self.competitor_price_for_month(level, d.month)
            price = self.pe.recommend_price(float(pred[i]), base_rate, comp)
            text = self.pe.explain_day(self.features, rows.iloc[i], shap_values[i], self.train_median,
                                       float(pred[i]), price, base_rate, comp)
            out.append({
                "date": d.isoformat(),
                "predicted_occupancy": round(float(pred[i]), 1),
                "recommended_price": price,
                "competitor_price": round(comp),
                "explanation": text,
            })
        return out, {"competitor_source": source, "scraped_hotels_used": n, "market_level_lkr": round(level)}
